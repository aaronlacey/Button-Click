function addLike(id){
    document.getElementById(id).innerText++
}

function hide(element) {
    element.remove();
}